"""Network-free reanalysis of the measurement candidate with direct device identifiers removed."""
from pathlib import Path
import sys,json,argparse
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'code'))
import pose_core as a
from pixel_core import bundle,errors,optimize
parser=argparse.ArgumentParser();parser.add_argument('--all-subsets',action='store_true');parser.add_argument('--objectives',action='store_true');args=parser.parse_args();out=ROOT/'replication_results';out.mkdir(exist_ok=True);saved=pd.read_csv(ROOT/'subset_membership_and_results.csv');expected=pd.read_csv(ROOT/'expected_full_results.csv');rows=[];checks=[]
def rms(v):return float(np.sqrt(np.mean(v*v)))
for panel in json.loads((ROOT/'panels.json').read_text()):
 name=panel['panel'];n=np.load(ROOT/'inputs'/(name+'.npz'));frames=[]
 for i in range(len(n['frame_G'])):
  ix=n['corner_frame_index']==i;frames.append(dict(G=n['frame_G'][i],C=n['frame_C'][i],pose_id=str(n['frame_pose_id'][i]),split=str(n['frame_split'][i]),obj=n['corner_object_points'][ix],img=n['corner_image_points'][ix]))
 for split,prefix in [('train','train'),('validation','held')]:
  for i,pid in enumerate(n[prefix+'_pose_ids']):
   group=[f for f in frames if f['split']==split and f['pose_id']==pid]
   assert np.max(abs(a.meanT(np.array([f['G'] for f in group]))-n[prefix+'_G'][i]))<1e-12
   assert np.max(abs(a.meanT(np.array([f['C'] for f in group]))-n[prefix+'_C'][i]))<1e-12
 tr=[f for f in frames if f['split']=='train'];held=[f for f in frames if f['split']=='validation'];tb=bundle(tr);vb=bundle(held);G=n['train_G'];C=n['train_C'];H=n['held_G'];B=n['held_C'];K=n['K'];D=n['D'];X,Z=a.fit(G,C);models=[('redetected_Park',X,Z)]
 if args.objectives:
  xx,zz=a.fit(G,n['train_C_archived']);models.append(('archived_Park',xx,zz))
  xx,zz,op=a.refine(G,C,X,Z);models.append(('redetected_pose_refined',xx,zz));xx,zz,op=optimize(tb,K,D,X,Z);models.append(('pixel_refined',xx,zz))
 for method,xx,zz in models:
  t,r=a.residuals(H,B,xx,zz);pix,_=errors(vb,K,D,xx,zz);row=dict(panel=name,method=method,translation_rms_mm=rms(t),rotation_rms_deg=rms(r),pixel_rms_px=pix);rows.append(row);ref=expected[(expected.panel==name)&(expected.method==method)].iloc[0];delta=max(abs(row[k]-ref[k]) for k in ['translation_rms_mm','rotation_rms_deg','pixel_rms_px']);checks.append(dict(panel=name,test=method,max_abs_delta=float(delta),pass_=bool(delta<1e-6)))
 candidates=saved[saved.panel==name]
 if not args.all_subsets:candidates=candidates[(candidates.budget==10)&(candidates.selection=='farthest')]
 lookup={str(pid):i for i,pid in enumerate(n['train_pose_ids'])}
 for rec in candidates.to_dict('records'):
  row={k:rec[k] for k in ['panel','budget','selection','replicate','selected_pose_ids']}
  try:
   ix=np.array([lookup[x] for x in rec['selected_pose_ids'].split(';')]);xx,zz=a.fit(G[ix],C[ix]);t,r=a.residuals(H,B,xx,zz);pix,_=errors(vb,K,D,xx,zz);row.update(translation_rms_mm=rms(t),rotation_rms_deg=rms(r),pixel_rms_px=pix,success=True);delta=max(abs(row[k]-rec[k]) for k in ['translation_rms_mm','rotation_rms_deg','pixel_rms_px']);checks.append(dict(panel=name,test='subset',max_abs_delta=float(delta),pass_=bool(bool(rec['success']) and delta<1e-6)))
  except Exception as ex:row.update(success=False,error=str(ex));checks.append(dict(panel=name,test='failed_subset',pass_=not bool(rec['success'])))
  rows.append(row)
 print('replicated',name,flush=True)
pd.DataFrame(rows).to_csv(out/'results.csv',index=False);(out/'checks.json').write_text(json.dumps(checks,indent=2));assert all(c['pass_'] for c in checks),'Mismatch in reconstructed numerical outputs';print('All measurement-level checks passed',len(checks),flush=True)
