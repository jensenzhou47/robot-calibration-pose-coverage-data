import numpy as np
from scipy.optimize import least_squares
from pose_core import inv,pack,unpack

def projection(G,obj,frame,K,D,X,Z):
 T=inv(G@X)@Z;points=np.einsum('nij,nj->ni',T[frame,:3,:3],obj)+T[frame,:3,3]
 xy=points[:,:2]/points[:,2,None];x=xy[:,0];y=xy[:,1];r2=x*x+y*y;k1,k2,p1,p2,k3=D
 f=1+k1*r2+k2*r2*r2+k3*r2*r2*r2
 return np.c_[K[0,0]*(x*f+2*p1*x*y+p2*(r2+2*x*x))+K[0,2],K[1,1]*(y*f+p1*(r2+2*y*y)+2*p2*x*y)+K[1,2]]

def bundle(frames):
 G=np.array([f['G'] for f in frames]);obj=np.concatenate([f['obj'] for f in frames]);img=np.concatenate([f['img'] for f in frames]);index=np.concatenate([np.full(len(f['obj']),i,dtype=int) for i,f in enumerate(frames)])
 poses=list(dict.fromkeys(f['pose_id'] for f in frames));counts={p:sum(f['pose_id']==p for f in frames) for p in poses}
 weights=np.concatenate([np.full(len(f['obj']),1/np.sqrt(len(f['obj'])*counts[f['pose_id']])) for f in frames])
 return dict(G=G,obj=obj,img=img,index=index,weights=weights,frames=frames,poses=poses)

def errors(b,K,D,X,Z):
 diff=projection(b['G'],b['obj'],b['index'],K,D,X,Z)-b['img'];sq=np.sum(diff*diff,axis=1)
 perframe=np.array([sq[b['index']==i].mean() for i in range(len(b['G']))]);perpose={p:float(np.mean([perframe[i] for i,f in enumerate(b['frames']) if f['pose_id']==p])) for p in b['poses']}
 return float(np.sqrt(np.mean(list(perpose.values())))),perpose

def optimize(b,K,D,X,Z,fixedX=False):
 def fun(a):
  xx=X if fixedX else pack(a[:6]);zz=pack(a if fixedX else a[6:])
  return ((projection(b['G'],b['obj'],b['index'],K,D,xx,zz)-b['img'])*b['weights'][:,None]).ravel()
 x0=unpack(Z) if fixedX else np.r_[unpack(X),unpack(Z)]
 op=least_squares(fun,x0,max_nfev=120,loss='linear',x_scale='jac',ftol=1e-9,xtol=1e-9,gtol=1e-9)
 return (X if fixedX else pack(op.x[:6])),pack(op.x if fixedX else op.x[6:]),op
