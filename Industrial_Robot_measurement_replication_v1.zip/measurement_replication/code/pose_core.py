import numpy as np,cv2,itertools
from scipy.spatial.transform import Rotation
from scipy.optimize import least_squares
METHODS={'Tsai': 0, 'Park': 1, 'Horaud': 2, 'Andreff': 3, 'Daniilidis': 4}
PARAM={'seed': 20261019, 'budgets': [6, 10, 15, 20], 'random_subsets': 100, 'bootstrap_replicates': 5000, 'selection_rotation_scale_deg': 10, 'selection_translation_scale_m': 0.1, 'unit': 'pose', 'primary_solver': 'Park', 'validation': 'historical split, previously inspected; retrospective validation, not untouched final test', 'nonlinear_translation_scale_m': 0.01, 'nonlinear_rotation_scale_deg': 1, 'selection_uses': 'training FK transforms only'}

def inv(T):
 r=np.swapaxes(T[...,:3,:3],-1,-2);o=np.zeros_like(T);o[...,:3,:3]=r;o[...,:3,3]=-np.einsum('...ij,...j->...i',r,T[...,:3,3]);o[...,3,3]=1;return o

def meanT(A):
 T=np.eye(4);T[:3,:3]=Rotation.from_matrix(A[:,:3,:3]).mean().as_matrix();T[:3,3]=A[:,:3,3].mean(0);return T

def pack(x):
 T=np.eye(4);T[:3,:3]=Rotation.from_rotvec(x[:3]).as_matrix();T[:3,3]=x[3:];return T

def unpack(T):return np.r_[Rotation.from_matrix(T[:3,:3]).as_rotvec(),T[:3,3]]

def fit(G,C,method='Park'):
 R,t=cv2.calibrateHandEye(list(G[:,:3,:3]),list(G[:,:3,3]),list(C[:,:3,:3]),list(C[:,:3,3]),method=METHODS[method]);X=np.eye(4);X[:3,:3]=R;X[:3,3]=t.ravel()
 if not np.isfinite(X).all() or np.linalg.det(R)<0.99:raise ValueError('Invalid hand-eye estimate')
 if method=='Tsai' and np.allclose(R,np.eye(3),atol=1e-14) and np.allclose(t,0,atol=1e-14):raise ValueError('OpenCV Tsai returned failure sentinel identity with zero translation; insufficient informative motions')
 return X,meanT(G@X@C)

def residuals(G,C,X,Z):
 Q=G@X@C;trans=np.linalg.norm(Q[:,:3,3]-Z[:3,3],axis=1)*1000
 rot=np.rad2deg(Rotation.from_matrix(np.einsum('ji,njk->nik',Z[:3,:3],Q[:,:3,:3])).magnitude())
 return trans,rot

def refine(G,C,X,Z):
 def fun(x):
  Q=G@pack(x[:6])@C;z=pack(x[6:]);t=(Q[:,:3,3]-z[:3,3])/PARAM['nonlinear_translation_scale_m'];r=Rotation.from_matrix(np.einsum('ji,njk->nik',z[:3,:3],Q[:,:3,:3])).as_rotvec()/np.deg2rad(PARAM['nonlinear_rotation_scale_deg']);return np.c_[t,r].ravel()
 out=least_squares(fun,np.r_[unpack(X),unpack(Z)],max_nfev=200,loss='soft_l1',ftol=1e-10,xtol=1e-10,gtol=1e-10)
 return pack(out.x[:6]),pack(out.x[6:]),out

def geometry(G):
 pairs=list(itertools.combinations(range(len(G)),2));rel=np.array([inv(G[i])@G[j] for i,j in pairs]);rot=Rotation.from_matrix(rel[:,:3,:3]).as_rotvec();s=np.linalg.svd(rot,compute_uv=False);A=(rel[:,:3,:3]-np.eye(3)).reshape(-1,3);st=np.linalg.svd(A,compute_uv=False)
 return {'rotation_span_deg':float(np.rad2deg(np.linalg.norm(rot,axis=1)).max()),'translation_span_mm':float(max(np.linalg.norm(G[i,:3,3]-G[j,:3,3]) for i,j in pairs)*1000),'rotation_axis_ratio':float(s[-1]/s[0]),'translation_condition':float(st[0]/st[-1])}

def select(G,k,kind,rng=None):
 n=len(G);D=np.zeros((n,n))
 for i in range(n):
  angle=Rotation.from_matrix(np.einsum('ji,njk->nik',G[i,:3,:3],G[:,:3,:3])).magnitude()/np.deg2rad(PARAM['selection_rotation_scale_deg']);trans=np.linalg.norm(G[:,:3,3]-G[i,:3,3],axis=1)/PARAM['selection_translation_scale_m'];D[i]=np.sqrt(angle**2+trans**2)
 medoid=np.argmin(D.sum(0))
 if kind=='clustered':return np.sort(np.argsort(D[medoid],kind='stable')[:k])
 if kind=='chronological':return np.arange(k)
 if kind=='random':return np.sort(rng.choice(n,k,replace=False))
 selected=[int(np.argmax(D[medoid]))]
 while len(selected)<k:
  d=D[selected].min(0);d[selected]=-1;selected.append(int(np.argmax(d)))
 return np.sort(selected)
